#include <iostream>
#include "engine/Engine.h"

using namespace std;

int main() {
	Engine::Init();

	GLFWwindow* window = Engine::CreateWindow(1280, 720);

	float vertices[] = {
		0.0, 0.5, 0.0,
		-0.5, -0.5, 0.0,
		0.5, -0.5, 0.0
	};

	Engine::Run(window, vertices);

	Engine::End();
	return 0;
}