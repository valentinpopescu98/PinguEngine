#include "Engine.h"

int Engine::Init() {
	// Initialize GLFW
	if (!glfwInit()) {
		return -1;
	}

	/*glfwWindowHint(GLFW_VISIBLE, props.visible);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);*/
}

void Engine::End() {
	glfwTerminate();
}

int Engine::FailCreateWindow(GLFWwindow* window) {
	if (!window) {
		cout << "Failed to create GLFW window." << endl;
		glfwTerminate();
		return -1;
	}
}

GLFWwindow* Engine::CreateWindow(int resX, int resY) {
	// Create window
	GLFWwindow* window = glfwCreateWindow(resX, resY, "Pingu Engine", NULL, NULL);

	Engine::FailCreateWindow(window);

	// Make window's context current
	glfwMakeContextCurrent(window);
	
	return window;
}

void Engine::BeforeDrawing() {
	glfwPollEvents();
	glClear(GL_COLOR_BUFFER_BIT);
}

void Engine::Draw(float vertices[]) {
	// Draw something
	glEnableClientState(GL_VERTEX_ARRAY);
	glVertexPointer(3, GL_FLOAT, 0, vertices);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDisableClientState(GL_VERTEX_ARRAY);
}

void Engine::AfterDrawing(GLFWwindow* window) {
	// Swap front and back buffer
	glfwSwapBuffers(window);
}

void Engine::Run(GLFWwindow* window, float vertices[]) {
	// Loop until window is closed
	while (!glfwWindowShouldClose(window)) {
		Engine::BeforeDrawing();

		Engine::Draw(vertices);

		Engine::AfterDrawing(window);
	}
}