#pragma once
#include <GLEW/glew.h>
#include <GLFW/glfw3.h>
#include <iostream>

using namespace std;

class Engine
{
public:
	static int Init();
	static void Run(GLFWwindow* window, float vertices[]);
	static void End();

	static GLFWwindow* CreateWindow(int resX, int resY);
	static void BeforeDrawing();
	static void Draw(float vertices[]);
	static void AfterDrawing(GLFWwindow* window);

private:
	static int FailCreateWindow(GLFWwindow* window);
};