# Skyroads
OpenGL game created by me with the Faculty of Automatic Control and Computers' framework.
All right's reserved to Universitatea Politehnica din Bucuresti, Faculty of Automatic Control and Computer's and all the authors to the framework which I have used.

POSSIBLE IMPROVEMENTS:
  Make the power-up deformation look better.
  Make the fuel counter border empty (without that X from the box's triangles).
